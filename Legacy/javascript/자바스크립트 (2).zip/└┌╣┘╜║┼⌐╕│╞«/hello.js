console.log("nodejs를 활용해보자");
console.log("실행방법 : node 파일명 ");

//ctrl ~ 